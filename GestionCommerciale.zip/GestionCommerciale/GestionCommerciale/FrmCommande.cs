﻿using GestionCommerciale.Entity;
using GestionCommerciale.Entity.GesComTableAdapters;
using GestionCommerciale.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionCommerciale
{
    public partial class FrmCommande : Form
    {
        private GesComServices service = new GesComServices();
        private int i;

        public FrmCommande()
        {
            InitializeComponent();
        }


        private void btnSaveClient_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNom.Text) || string.IsNullOrEmpty(txtPrenom.Text) || string.IsNullOrEmpty(txtAdresse.Text) || string.IsNullOrEmpty(txtTel.Text))
            {
                MessageBox.Show("Veuillez remplir tous les champs", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                Client cli = new Client()
                {
                    Prenom = txtPrenom.Text,
                    Nom = txtNom.Text,
                    Adresse = txtAdresse.Text,
                    Telephone = txtTel.Text
                };
                service.AddClient(cli);
                MessageBox.Show("Un client est Ajouté ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnRechercheClient_Click(object sender, EventArgs e)
        {

            int cmp = 0;
            for (int i = 0; i < this.dataGridView1.Rows.Count - 1; i++)
            {
                if (this.dataGridView1.Rows[i].Cells[4].Value.ToString() == this.txtTelephoneRech.Text)
                {
                    txtIdRech.Text = this.dataGridView1.Rows[i].Cells[0].Value.ToString();
                    txtNomRech.Text = this.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    txtPrenomRech.Text = this.dataGridView1.Rows[i].Cells[2].Value.ToString();
                    txtAdresseRech.Text = this.dataGridView1.Rows[i].Cells[3].Value.ToString();
                    cmp = 1;
                }
            }
            if (cmp == 0)
            {
                MessageBox.Show("Ce client n'existe pas");
                groupBox1.Enabled = true;

            }
        }


        private void btnRechercheArticle_Click(object sender, EventArgs e)
        {
            int cmp = 0;
            for (int i = 0; i < this.dataGridViewAr.Rows.Count - 1; i++)
            {
                if (this.dataGridViewAr.Rows[i].Cells[1].Value.ToString() == this.txtRefRech.Text)
                {
                    txtLibRech.Text = this.dataGridViewAr.Rows[i].Cells[2].Value.ToString();
                    txtQuantRech.Text = this.dataGridViewAr.Rows[i].Cells[3].Value.ToString();
                    txtRechPrix.Text = this.dataGridViewAr.Rows[i].Cells[4].Value.ToString();
                    cmp = 1;
                }
            }
            if (cmp == 0)
            {
                MessageBox.Show("Ce produit n'existe pas");
                txtRefRech.Clear();
            }
        }

    

        private void FrmCommande_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'gesCom1.Commande'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.commandeTableAdapter.Fill(this.gesCom1.Commande);
            // TODO: cette ligne de code charge les données dans la table 'gesCom1.Article'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.articleTableAdapter.Fill(this.gesCom1.Article);
            // TODO: cette ligne de code charge les données dans la table 'gesCom.Client'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.clientTableAdapter.Fill(this.gesCom.Client);

            btnAdd.Enabled = false;
            groupBox1.Enabled = false;

        }


        private void btnAddCommande_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtQuantCom.Text) || string.IsNullOrEmpty(txtNumCom.Text))
            {
                if (string.IsNullOrEmpty(txtNomRech.Text) || string.IsNullOrEmpty(txtPrenom.Text) || string.IsNullOrEmpty(txtAdresseRech.Text))
                {
                    if (string.IsNullOrEmpty(txtLibRech.Text) || string.IsNullOrEmpty(txtQuantRech.Text))
                    {
                        MessageBox.Show("Veuillez choisir l'article", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    MessageBox.Show("Veuiller identifier le client", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                MessageBox.Show("Veuillez remplir tous les champs", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int c = int.Parse(txtQuantCom.Text);
                int p = int.Parse(txtRechPrix.Text);
                int q = int.Parse(txtQuantRech.Text);
                String Montant = (p * c).ToString();
                if(c>q)
                {
                    MessageBox.Show("Le stock est inferieur à la quantitié demandée", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                Commande com = new Commande()
                {
                    Numero_Commande = txtNumCom.Text,
                    Date = txtDateCom.Text,
                    Quantite = int.Parse(txtQuantCom.Text),
               
                }; 
                if (service.AddCommande(com))
                {
                    

                    dgvCommande.Rows.Add(txtIdRech.Text,txtLibRech.Text,txtRechPrix.Text,txtQuantCom.Text, Montant);
                    MessageBox.Show("Produit Ajoutée avec succes", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.commandeTableAdapter.Fill(this.gesCom1.Commande);

                    txtRefRech.Clear();
                    txtQuantCom.Clear();
                    txtQuantRech.Clear();
                    txtLibRech.Clear();

                    for (int i = 0; i < this.dgvCommande.Rows.Count - 1; i++)
                    {
                        txtTotal.Text = txtTotal.Text + Montant;
                    }
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            FrmCommande f = new FrmCommande();
            f.Close();
        }
    }
}
