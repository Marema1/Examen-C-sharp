﻿using GestionCommerciale.Entity;
using GestionCommerciale.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionCommerciale
{
    public partial class FrmConnexion : Form
    {
        private GesComServices service = new GesComServices();
        public FrmConnexion()
        {
            InitializeComponent();
        }

        private void lblError_Click(object sender, EventArgs e)
        {

        }

       FrmAccueil frmAcc;
        private void btnConnect_Click(object sender, EventArgs e)
        {
            User user = service.SeConnecter(txtLogin.Text.Trim(), txtPassword.Text.Trim());
            if (user == null)
            {
                lblError.Visible = true;
            }
            else
            {
                frmAcc = new FrmAccueil(user);
                frmAcc.Show();
                

            }
        }

        FrmUser frmUse;
        private void btnInscrire_Click(object sender, EventArgs e)
        {
            frmUse = new FrmUser();
            frmUse.Show();
           this.Hide();

        }

        private void FrmConnexion_Load(object sender, EventArgs e)
        {

        }
    }
}
