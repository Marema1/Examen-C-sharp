﻿using GestionCommerciale.Entity;
using GestionCommerciale.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionCommerciale
{
    public partial class FrmAccueil : Form
    {
      User user;
        public FrmAccueil()
        {
           InitializeComponent();
           
            
        }
        public FrmAccueil(User user)
        {
            InitializeComponent();
            this.user = user;
        }

        private void btnCategorie_Click(object sender, EventArgs e)
        {

        }

        FrmArticle frmArt;
        private void btnArticle_Click(object sender, EventArgs e)
        {
            clearChild();
            frmArt = new FrmArticle();
            frmArt.MdiParent = this;
            frmArt.Show();

        }

        private void clearChild()
        {
            foreach (Form f in this.MdiChildren)
            {
                f.Close();
            }
        }

        FrmCommande frmCom;
        private void btnCommande_Click(object sender, EventArgs e)
        {
            clearChild();
            frmCom = new FrmCommande();
            frmCom.MdiParent = this;
            frmCom.Show();
        }

        private void btnProfil_Click(object sender, EventArgs e)
        {

        }

        FrmUser frmUser;
        private void btnUser_Click(object sender, EventArgs e)
        {
            clearChild();
            frmUser = new FrmUser();
            frmUser.MdiParent = this;
            frmUser.Show();
        }

        private void FrmAccueil_Load(object sender, EventArgs e)
        {
            StartPosition = FormStartPosition.CenterParent;
            
        }

        
    }
}
