﻿using GestionCommerciale.Entity;
using GestionCommerciale.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GestionCommerciale
{
    public partial class FrmUser : Form
    {
        private GesComServices service = new GesComServices();
        private List<User> users;
        Profil profilSelect;
       

        public FrmUser(object user)
        {
            InitializeComponent();
        }

        public FrmUser()
        {
            InitializeComponent();
        }

        private void FrmUser_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'gesCom.User'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.userTableAdapter.Fill(this.gesCom.User);
            // TODO: cette ligne de code charge les données dans la table 'gestionComDataSet2.Profil'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.profilTableAdapter1.Fill(this.gestionComDataSet2.Profil);
        }

        private void btnSaveUser_click(object sender, EventArgs e)
        {
            User use = new User();
            if (string.IsNullOrEmpty(txtLogin.Text) || string.IsNullOrEmpty(txtPassword.Text) || string.IsNullOrEmpty(txtNom.Text) || string.IsNullOrEmpty(txtPrenom.Text))
            {
                if (txtPassword.Text.CompareTo(txtConfirmer.Text) == 0)
                {
                    if (txtLogin.Text.CompareTo(use.Login) == 0)
                    {
                        MessageBox.Show("Ce login existe deja", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    MessageBox.Show("Les deux mots de passe ne sont pas conformes", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                MessageBox.Show("Veuillez saisir tous les champs", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                User user = new User()
                {

                    Prenom = txtPrenom.Text,
                    Login = txtLogin.Text,
                    Password = txtPassword.Text,
                    Nom = txtNom.Text,
                    Profil = profilSelect
                };

                if (service.AddUser(user))
                {

                    MessageBox.Show("L'utilisateur a été Ajouté ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.userTableAdapter.Fill(this.gesCom.User);
                    txtLogin.Clear();
                    txtPassword.Clear();
                    txtConfirmer.Clear();
                    txtNom.Clear();
                    txtPrenom.Clear();
                }
            }
        }

        FrmConnexion frnCon;
        private void btnClose_Click(object sender, EventArgs e)
        {
            frnCon = new FrmConnexion();
            frnCon.Show();
            this.Hide();
        }
    }
}
