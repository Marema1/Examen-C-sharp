namespace GestionCommerciale.Entity
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class GesComModel : DbContext
    {
        public GesComModel()
            : base("name=GesComModel3")
        {
        }

        public virtual DbSet<Article> Article { get; set; }
        public virtual DbSet<Categorie> Categorie { get; set; }
        public virtual DbSet<Client> Client { get; set; }
        public virtual DbSet<Commande> Commande { get; set; }
        public virtual DbSet<Profil> Profil { get; set; }
        public virtual DbSet<User> User { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Profil>()
                .HasMany(e => e.User)
                .WithRequired(e => e.Profil)
                .WillCascadeOnDelete(false);
        }
    }
}
