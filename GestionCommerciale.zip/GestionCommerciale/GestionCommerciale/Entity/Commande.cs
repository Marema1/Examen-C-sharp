namespace GestionCommerciale.Entity
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Commande")]
    public partial class Commande
    {
        [Key]
        
        public int Id_Commande { get; set; }

        [Required]
        [StringLength(50)]
        public string Numero_Commande { get; set; }

        [StringLength(50)]
        public string Date { get; set; }

        public int? Quantite { get; set; }

        public double? Montant { get; set; }
    }
}
