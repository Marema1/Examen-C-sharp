﻿namespace GestionCommerciale
{
    partial class FrmCommande
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.commandeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gesCom1 = new GestionCommerciale.Entity.GesCom();
            this.clientBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gesCom = new GestionCommerciale.Entity.GesCom();
            this.clientTableAdapter = new GestionCommerciale.Entity.GesComTableAdapters.ClientTableAdapter();
            this.dataGridViewAr = new System.Windows.Forms.DataGridView();
            this.idArticleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.referenceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.libelleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prixDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categorieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.articleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.articleTableAdapter = new GestionCommerciale.Entity.GesComTableAdapters.ArticleTableAdapter();
            this.commandeTableAdapter = new GestionCommerciale.Entity.GesComTableAdapters.CommandeTableAdapter();
            this.clientBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idClientDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prenomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adresseDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telephoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtNom = new System.Windows.Forms.TextBox();
            this.txtPrenom = new System.Windows.Forms.TextBox();
            this.txtTel = new System.Windows.Forms.TextBox();
            this.txtAdresse = new System.Windows.Forms.TextBox();
            this.btnSaveClient = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Nom = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNumCom = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtDateCom = new System.Windows.Forms.DateTimePicker();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.dgvCommande = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtRefRech = new System.Windows.Forms.TextBox();
            this.txtQuantCom = new System.Windows.Forms.TextBox();
            this.txtQuantRech = new System.Windows.Forms.TextBox();
            this.btnAddCommande = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.panel26 = new System.Windows.Forms.Panel();
            this.btnRechArticle = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.panel31 = new System.Windows.Forms.Panel();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.panel32 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.txtLibRech = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtAdresseRech = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.panel20 = new System.Windows.Forms.Panel();
            this.txtPrenomRech = new System.Windows.Forms.TextBox();
            this.btnRecherche = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txtNomRech = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTelephoneRech = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.txtDate = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.panel33 = new System.Windows.Forms.Panel();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Libelle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prix = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantite = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Montant = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txtRechPrix = new System.Windows.Forms.Label();
            this.txtIdRech = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.commandeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gesCom1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gesCom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel7.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCommande)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel16.SuspendLayout();
            this.SuspendLayout();
            // 
            // commandeBindingSource
            // 
            this.commandeBindingSource.DataMember = "Commande";
            this.commandeBindingSource.DataSource = this.gesCom1;
            // 
            // gesCom1
            // 
            this.gesCom1.DataSetName = "GesCom";
            this.gesCom1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // clientBindingSource
            // 
            this.clientBindingSource.DataMember = "Client";
            this.clientBindingSource.DataSource = this.gesCom;
            // 
            // gesCom
            // 
            this.gesCom.DataSetName = "GesCom";
            this.gesCom.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // clientTableAdapter
            // 
            this.clientTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewAr
            // 
            this.dataGridViewAr.AutoGenerateColumns = false;
            this.dataGridViewAr.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewAr.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewAr.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewAr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAr.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idArticleDataGridViewTextBoxColumn,
            this.referenceDataGridViewTextBoxColumn,
            this.libelleDataGridViewTextBoxColumn,
            this.stockDataGridViewTextBoxColumn,
            this.prixDataGridViewTextBoxColumn,
            this.categorieDataGridViewTextBoxColumn});
            this.dataGridViewAr.DataSource = this.articleBindingSource;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewAr.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewAr.EnableHeadersVisualStyles = false;
            this.dataGridViewAr.Location = new System.Drawing.Point(12, 334);
            this.dataGridViewAr.Name = "dataGridViewAr";
            this.dataGridViewAr.Size = new System.Drawing.Size(127, 209);
            this.dataGridViewAr.TabIndex = 35;
            this.dataGridViewAr.Visible = false;
            // 
            // idArticleDataGridViewTextBoxColumn
            // 
            this.idArticleDataGridViewTextBoxColumn.DataPropertyName = "Id_Article";
            this.idArticleDataGridViewTextBoxColumn.HeaderText = "Id_Article";
            this.idArticleDataGridViewTextBoxColumn.Name = "idArticleDataGridViewTextBoxColumn";
            this.idArticleDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // referenceDataGridViewTextBoxColumn
            // 
            this.referenceDataGridViewTextBoxColumn.DataPropertyName = "Reference";
            this.referenceDataGridViewTextBoxColumn.HeaderText = "Reference";
            this.referenceDataGridViewTextBoxColumn.Name = "referenceDataGridViewTextBoxColumn";
            // 
            // libelleDataGridViewTextBoxColumn
            // 
            this.libelleDataGridViewTextBoxColumn.DataPropertyName = "Libelle";
            this.libelleDataGridViewTextBoxColumn.HeaderText = "Libelle";
            this.libelleDataGridViewTextBoxColumn.Name = "libelleDataGridViewTextBoxColumn";
            // 
            // stockDataGridViewTextBoxColumn
            // 
            this.stockDataGridViewTextBoxColumn.DataPropertyName = "Stock";
            this.stockDataGridViewTextBoxColumn.HeaderText = "Stock";
            this.stockDataGridViewTextBoxColumn.Name = "stockDataGridViewTextBoxColumn";
            // 
            // prixDataGridViewTextBoxColumn
            // 
            this.prixDataGridViewTextBoxColumn.DataPropertyName = "Prix";
            this.prixDataGridViewTextBoxColumn.HeaderText = "Prix";
            this.prixDataGridViewTextBoxColumn.Name = "prixDataGridViewTextBoxColumn";
            // 
            // categorieDataGridViewTextBoxColumn
            // 
            this.categorieDataGridViewTextBoxColumn.DataPropertyName = "Categorie";
            this.categorieDataGridViewTextBoxColumn.HeaderText = "Categorie";
            this.categorieDataGridViewTextBoxColumn.Name = "categorieDataGridViewTextBoxColumn";
            // 
            // articleBindingSource
            // 
            this.articleBindingSource.DataMember = "Article";
            this.articleBindingSource.DataSource = this.gesCom1;
            // 
            // articleTableAdapter
            // 
            this.articleTableAdapter.ClearBeforeFill = true;
            // 
            // commandeTableAdapter
            // 
            this.commandeTableAdapter.ClearBeforeFill = true;
            // 
            // clientBindingSource1
            // 
            this.clientBindingSource1.DataMember = "Client";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.txtNom);
            this.groupBox1.Controls.Add(this.txtPrenom);
            this.groupBox1.Controls.Add(this.txtTel);
            this.groupBox1.Controls.Add(this.txtAdresse);
            this.groupBox1.Controls.Add(this.btnSaveClient);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.panel7);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.Nom);
            this.groupBox1.Controls.Add(this.panel6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(-4, -16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(248, 588);
            this.groupBox1.TabIndex = 36;
            this.groupBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idClientDataGridViewTextBoxColumn,
            this.nomDataGridViewTextBoxColumn,
            this.prenomDataGridViewTextBoxColumn,
            this.adresseDataGridViewTextBoxColumn,
            this.telephoneDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.clientBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(-46, 355);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(305, 150);
            this.dataGridView1.TabIndex = 34;
            this.dataGridView1.Visible = false;
            // 
            // idClientDataGridViewTextBoxColumn
            // 
            this.idClientDataGridViewTextBoxColumn.DataPropertyName = "Id_Client";
            this.idClientDataGridViewTextBoxColumn.HeaderText = "Id_Client";
            this.idClientDataGridViewTextBoxColumn.Name = "idClientDataGridViewTextBoxColumn";
            this.idClientDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nomDataGridViewTextBoxColumn
            // 
            this.nomDataGridViewTextBoxColumn.DataPropertyName = "Nom";
            this.nomDataGridViewTextBoxColumn.HeaderText = "Nom";
            this.nomDataGridViewTextBoxColumn.Name = "nomDataGridViewTextBoxColumn";
            // 
            // prenomDataGridViewTextBoxColumn
            // 
            this.prenomDataGridViewTextBoxColumn.DataPropertyName = "Prenom";
            this.prenomDataGridViewTextBoxColumn.HeaderText = "Prenom";
            this.prenomDataGridViewTextBoxColumn.Name = "prenomDataGridViewTextBoxColumn";
            // 
            // adresseDataGridViewTextBoxColumn
            // 
            this.adresseDataGridViewTextBoxColumn.DataPropertyName = "Adresse";
            this.adresseDataGridViewTextBoxColumn.HeaderText = "Adresse";
            this.adresseDataGridViewTextBoxColumn.Name = "adresseDataGridViewTextBoxColumn";
            // 
            // telephoneDataGridViewTextBoxColumn
            // 
            this.telephoneDataGridViewTextBoxColumn.DataPropertyName = "Telephone";
            this.telephoneDataGridViewTextBoxColumn.HeaderText = "Telephone";
            this.telephoneDataGridViewTextBoxColumn.Name = "telephoneDataGridViewTextBoxColumn";
            // 
            // txtNom
            // 
            this.txtNom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtNom.BackColor = System.Drawing.SystemColors.Control;
            this.txtNom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNom.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtNom.Location = new System.Drawing.Point(49, 69);
            this.txtNom.Multiline = true;
            this.txtNom.Name = "txtNom";
            this.txtNom.Size = new System.Drawing.Size(167, 21);
            this.txtNom.TabIndex = 33;
            // 
            // txtPrenom
            // 
            this.txtPrenom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtPrenom.BackColor = System.Drawing.SystemColors.Control;
            this.txtPrenom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPrenom.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtPrenom.Location = new System.Drawing.Point(49, 113);
            this.txtPrenom.Multiline = true;
            this.txtPrenom.Name = "txtPrenom";
            this.txtPrenom.Size = new System.Drawing.Size(166, 21);
            this.txtPrenom.TabIndex = 32;
            // 
            // txtTel
            // 
            this.txtTel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtTel.BackColor = System.Drawing.SystemColors.Control;
            this.txtTel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTel.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtTel.Location = new System.Drawing.Point(66, 156);
            this.txtTel.Multiline = true;
            this.txtTel.Name = "txtTel";
            this.txtTel.Size = new System.Drawing.Size(149, 21);
            this.txtTel.TabIndex = 31;
            // 
            // txtAdresse
            // 
            this.txtAdresse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtAdresse.BackColor = System.Drawing.SystemColors.Control;
            this.txtAdresse.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAdresse.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtAdresse.Location = new System.Drawing.Point(54, 219);
            this.txtAdresse.Multiline = true;
            this.txtAdresse.Name = "txtAdresse";
            this.txtAdresse.Size = new System.Drawing.Size(154, 43);
            this.txtAdresse.TabIndex = 30;
            // 
            // btnSaveClient
            // 
            this.btnSaveClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.btnSaveClient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnSaveClient.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.btnSaveClient.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSaveClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSaveClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveClient.ForeColor = System.Drawing.SystemColors.GrayText;
            this.btnSaveClient.Location = new System.Drawing.Point(89, 293);
            this.btnSaveClient.Name = "btnSaveClient";
            this.btnSaveClient.Size = new System.Drawing.Size(95, 30);
            this.btnSaveClient.TabIndex = 29;
            this.btnSaveClient.Text = "Enregistrer";
            this.btnSaveClient.UseVisualStyleBackColor = false;
            this.btnSaveClient.Click += new System.EventHandler(this.btnSaveClient_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 217);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 13);
            this.label4.TabIndex = 25;
            this.label4.Text = "Adresse";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel7.Controls.Add(this.textBox6);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Location = new System.Drawing.Point(49, 265);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(167, 1);
            this.panel7.TabIndex = 24;
            // 
            // textBox6
            // 
            this.textBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox6.BackColor = System.Drawing.SystemColors.Control;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Location = new System.Drawing.Point(0, 62);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(203, 20);
            this.textBox6.TabIndex = 11;
            this.textBox6.Text = "Entrer le login";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel8.Location = new System.Drawing.Point(0, 83);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(204, 1);
            this.panel8.TabIndex = 10;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Telephone";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel3.Controls.Add(this.textBox3);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(49, 179);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(167, 1);
            this.panel3.TabIndex = 21;
            // 
            // textBox3
            // 
            this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox3.BackColor = System.Drawing.SystemColors.Control;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Location = new System.Drawing.Point(0, 62);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(203, 20);
            this.textBox3.TabIndex = 11;
            this.textBox3.Text = "Entrer le login";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel4.Location = new System.Drawing.Point(0, 83);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(204, 1);
            this.panel4.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Prenom";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Location = new System.Drawing.Point(48, 136);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(167, 1);
            this.panel2.TabIndex = 18;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(0, 62);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(203, 20);
            this.textBox1.TabIndex = 11;
            this.textBox1.Text = "Entrer le login";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel5.Location = new System.Drawing.Point(0, 83);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(204, 1);
            this.panel5.TabIndex = 10;
            // 
            // Nom
            // 
            this.Nom.AutoSize = true;
            this.Nom.Location = new System.Drawing.Point(7, 82);
            this.Nom.Name = "Nom";
            this.Nom.Size = new System.Drawing.Size(29, 13);
            this.Nom.TabIndex = 16;
            this.Nom.Text = "Nom";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel6.Controls.Add(this.textBox5);
            this.panel6.Controls.Add(this.panel9);
            this.panel6.Location = new System.Drawing.Point(49, 90);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(167, 1);
            this.panel6.TabIndex = 15;
            // 
            // textBox5
            // 
            this.textBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox5.BackColor = System.Drawing.SystemColors.Control;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Location = new System.Drawing.Point(0, 62);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(203, 20);
            this.textBox5.TabIndex = 11;
            this.textBox5.Text = "Entrer le login";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel9.Location = new System.Drawing.Point(0, 83);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(204, 1);
            this.panel9.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.label1.Location = new System.Drawing.Point(51, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Enregistrement Client";
            // 
            // txtNumCom
            // 
            this.txtNumCom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtNumCom.BackColor = System.Drawing.SystemColors.Control;
            this.txtNumCom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNumCom.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtNumCom.Location = new System.Drawing.Point(57, 18);
            this.txtNumCom.Multiline = true;
            this.txtNumCom.Name = "txtNumCom";
            this.txtNumCom.Size = new System.Drawing.Size(157, 19);
            this.txtNumCom.TabIndex = 39;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.txtNumCom);
            this.groupBox2.Controls.Add(this.txtDateCom);
            this.groupBox2.Controls.Add(this.txtTotal);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.dgvCommande);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.btnAdd);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.panel14);
            this.groupBox2.Controls.Add(this.txtDate);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.panel16);
            this.groupBox2.Controls.Add(this.txtNumero);
            this.groupBox2.Location = new System.Drawing.Point(255, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(499, 573);
            this.groupBox2.TabIndex = 37;
            this.groupBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = global::GestionCommerciale.Properties.Resources.images__11_;
            this.pictureBox1.InitialImage = global::GestionCommerciale.Properties.Resources.images1;
            this.pictureBox1.Location = new System.Drawing.Point(469, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(24, 24);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 40;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.UseWaitCursor = true;
            this.pictureBox1.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtDateCom
            // 
            this.txtDateCom.CalendarMonthBackground = System.Drawing.SystemColors.Control;
            this.txtDateCom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtDateCom.Location = new System.Drawing.Point(49, 49);
            this.txtDateCom.Name = "txtDateCom";
            this.txtDateCom.Size = new System.Drawing.Size(170, 20);
            this.txtDateCom.TabIndex = 38;
            // 
            // txtTotal
            // 
            this.txtTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtTotal.BackColor = System.Drawing.SystemColors.Control;
            this.txtTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.ForeColor = System.Drawing.Color.Maroon;
            this.txtTotal.Location = new System.Drawing.Point(353, 544);
            this.txtTotal.Multiline = true;
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(96, 19);
            this.txtTotal.TabIndex = 35;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label15.Location = new System.Drawing.Point(293, 542);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 20);
            this.label15.TabIndex = 34;
            this.label15.Text = "Total :";
            // 
            // dgvCommande
            // 
            this.dgvCommande.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCommande.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.Libelle,
            this.Prix,
            this.Quantite,
            this.Montant});
            this.dgvCommande.Location = new System.Drawing.Point(-5, 339);
            this.dgvCommande.Name = "dgvCommande";
            this.dgvCommande.Size = new System.Drawing.Size(504, 195);
            this.dgvCommande.TabIndex = 33;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtIdRech);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.textBox4);
            this.groupBox4.Controls.Add(this.txtRechPrix);
            this.groupBox4.Controls.Add(this.txtRefRech);
            this.groupBox4.Controls.Add(this.txtQuantCom);
            this.groupBox4.Controls.Add(this.txtQuantRech);
            this.groupBox4.Controls.Add(this.btnAddCommande);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.panel23);
            this.groupBox4.Controls.Add(this.panel25);
            this.groupBox4.Controls.Add(this.btnRechArticle);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.panel27);
            this.groupBox4.Controls.Add(this.panel29);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.txtLibRech);
            this.groupBox4.Location = new System.Drawing.Point(6, 184);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(455, 141);
            this.groupBox4.TabIndex = 32;
            this.groupBox4.TabStop = false;
            // 
            // txtRefRech
            // 
            this.txtRefRech.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtRefRech.BackColor = System.Drawing.SystemColors.Control;
            this.txtRefRech.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtRefRech.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtRefRech.Location = new System.Drawing.Point(72, 17);
            this.txtRefRech.Multiline = true;
            this.txtRefRech.Name = "txtRefRech";
            this.txtRefRech.Size = new System.Drawing.Size(134, 19);
            this.txtRefRech.TabIndex = 40;
            // 
            // txtQuantCom
            // 
            this.txtQuantCom.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtQuantCom.BackColor = System.Drawing.SystemColors.Control;
            this.txtQuantCom.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQuantCom.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtQuantCom.Location = new System.Drawing.Point(367, 63);
            this.txtQuantCom.Multiline = true;
            this.txtQuantCom.Name = "txtQuantCom";
            this.txtQuantCom.Size = new System.Drawing.Size(66, 19);
            this.txtQuantCom.TabIndex = 39;
            // 
            // txtQuantRech
            // 
            this.txtQuantRech.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtQuantRech.BackColor = System.Drawing.SystemColors.Control;
            this.txtQuantRech.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtQuantRech.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtQuantRech.Location = new System.Drawing.Point(207, 69);
            this.txtQuantRech.Multiline = true;
            this.txtQuantRech.Name = "txtQuantRech";
            this.txtQuantRech.ReadOnly = true;
            this.txtQuantRech.Size = new System.Drawing.Size(42, 19);
            this.txtQuantRech.TabIndex = 38;
            // 
            // btnAddCommande
            // 
            this.btnAddCommande.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.btnAddCommande.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAddCommande.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.btnAddCommande.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAddCommande.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddCommande.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCommande.ForeColor = System.Drawing.SystemColors.GrayText;
            this.btnAddCommande.Location = new System.Drawing.Point(316, 103);
            this.btnAddCommande.Name = "btnAddCommande";
            this.btnAddCommande.Size = new System.Drawing.Size(58, 25);
            this.btnAddCommande.TabIndex = 36;
            this.btnAddCommande.Text = "Add";
            this.btnAddCommande.UseVisualStyleBackColor = false;
            this.btnAddCommande.Click += new System.EventHandler(this.btnAddCommande_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(258, 69);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 13);
            this.label11.TabIndex = 35;
            this.label11.Text = "Quantite Commande";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel23.Controls.Add(this.textBox8);
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Location = new System.Drawing.Point(259, 93);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(188, 1);
            this.panel23.TabIndex = 32;
            // 
            // textBox8
            // 
            this.textBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox8.BackColor = System.Drawing.SystemColors.Control;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Location = new System.Drawing.Point(0, 62);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(203, 20);
            this.textBox8.TabIndex = 11;
            this.textBox8.Text = "Entrer le login";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel24.Location = new System.Drawing.Point(0, 83);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(204, 1);
            this.panel24.TabIndex = 10;
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel25.Controls.Add(this.textBox14);
            this.panel25.Controls.Add(this.panel26);
            this.panel25.Location = new System.Drawing.Point(158, 92);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(85, 1);
            this.panel25.TabIndex = 33;
            // 
            // textBox14
            // 
            this.textBox14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox14.BackColor = System.Drawing.SystemColors.Control;
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox14.Location = new System.Drawing.Point(0, 62);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(203, 20);
            this.textBox14.TabIndex = 11;
            this.textBox14.Text = "Entrer le login";
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel26.Location = new System.Drawing.Point(0, 83);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(204, 1);
            this.panel26.TabIndex = 10;
            // 
            // btnRechArticle
            // 
            this.btnRechArticle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.btnRechArticle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRechArticle.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.btnRechArticle.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRechArticle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRechArticle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRechArticle.ForeColor = System.Drawing.SystemColors.GrayText;
            this.btnRechArticle.Location = new System.Drawing.Point(236, 14);
            this.btnRechArticle.Name = "btnRechArticle";
            this.btnRechArticle.Size = new System.Drawing.Size(81, 25);
            this.btnRechArticle.TabIndex = 32;
            this.btnRechArticle.Text = "Search";
            this.btnRechArticle.UseVisualStyleBackColor = false;
            this.btnRechArticle.Click += new System.EventHandler(this.btnRechercheArticle_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(159, 72);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 13);
            this.label12.TabIndex = 28;
            this.label12.Text = "Quantite";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 27);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(57, 13);
            this.label13.TabIndex = 25;
            this.label13.Text = "Reference";
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel27.Controls.Add(this.textBox16);
            this.panel27.Controls.Add(this.panel28);
            this.panel27.Location = new System.Drawing.Point(51, 38);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(167, 1);
            this.panel27.TabIndex = 24;
            // 
            // textBox16
            // 
            this.textBox16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox16.BackColor = System.Drawing.SystemColors.Control;
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox16.Location = new System.Drawing.Point(0, 62);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(203, 20);
            this.textBox16.TabIndex = 11;
            this.textBox16.Text = "Entrer le login";
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel28.Location = new System.Drawing.Point(0, 83);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(204, 1);
            this.panel28.TabIndex = 10;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel29.Controls.Add(this.panel30);
            this.panel29.Controls.Add(this.textBox19);
            this.panel29.Controls.Add(this.panel32);
            this.panel29.Location = new System.Drawing.Point(6, 92);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(139, 1);
            this.panel29.TabIndex = 24;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel30.Controls.Add(this.textBox18);
            this.panel30.Controls.Add(this.panel31);
            this.panel30.Location = new System.Drawing.Point(0, 0);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(139, 1);
            this.panel30.TabIndex = 25;
            // 
            // textBox18
            // 
            this.textBox18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox18.BackColor = System.Drawing.SystemColors.Control;
            this.textBox18.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox18.Location = new System.Drawing.Point(0, 62);
            this.textBox18.Multiline = true;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(203, 20);
            this.textBox18.TabIndex = 11;
            this.textBox18.Text = "Entrer le login";
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel31.Location = new System.Drawing.Point(0, 83);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(204, 1);
            this.panel31.TabIndex = 10;
            // 
            // textBox19
            // 
            this.textBox19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox19.BackColor = System.Drawing.SystemColors.Control;
            this.textBox19.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox19.Location = new System.Drawing.Point(0, 62);
            this.textBox19.Multiline = true;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(203, 20);
            this.textBox19.TabIndex = 11;
            this.textBox19.Text = "Entrer le login";
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel32.Location = new System.Drawing.Point(0, 83);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(204, 1);
            this.panel32.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 74);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 13);
            this.label14.TabIndex = 25;
            this.label14.Text = "Libelle";
            // 
            // txtLibRech
            // 
            this.txtLibRech.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtLibRech.BackColor = System.Drawing.SystemColors.Control;
            this.txtLibRech.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLibRech.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtLibRech.Location = new System.Drawing.Point(47, 67);
            this.txtLibRech.Multiline = true;
            this.txtLibRech.Name = "txtLibRech";
            this.txtLibRech.ReadOnly = true;
            this.txtLibRech.Size = new System.Drawing.Size(103, 19);
            this.txtLibRech.TabIndex = 23;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtAdresseRech);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.panel21);
            this.groupBox3.Controls.Add(this.panel19);
            this.groupBox3.Controls.Add(this.txtPrenomRech);
            this.groupBox3.Controls.Add(this.btnRecherche);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.panel11);
            this.groupBox3.Controls.Add(this.txtNomRech);
            this.groupBox3.Controls.Add(this.panel10);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtTelephoneRech);
            this.groupBox3.Location = new System.Drawing.Point(8, 70);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(445, 122);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            // 
            // txtAdresseRech
            // 
            this.txtAdresseRech.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtAdresseRech.BackColor = System.Drawing.SystemColors.Control;
            this.txtAdresseRech.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAdresseRech.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtAdresseRech.Location = new System.Drawing.Point(353, 68);
            this.txtAdresseRech.Multiline = true;
            this.txtAdresseRech.Name = "txtAdresseRech";
            this.txtAdresseRech.ReadOnly = true;
            this.txtAdresseRech.Size = new System.Drawing.Size(86, 21);
            this.txtAdresseRech.TabIndex = 34;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(302, 69);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 13);
            this.label10.TabIndex = 35;
            this.label10.Text = "Adresse";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel21.Controls.Add(this.textBox13);
            this.panel21.Controls.Add(this.panel22);
            this.panel21.Location = new System.Drawing.Point(305, 92);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(139, 1);
            this.panel21.TabIndex = 32;
            // 
            // textBox13
            // 
            this.textBox13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox13.BackColor = System.Drawing.SystemColors.Control;
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox13.Location = new System.Drawing.Point(0, 62);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(203, 20);
            this.textBox13.TabIndex = 11;
            this.textBox13.Text = "Entrer le login";
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel22.Location = new System.Drawing.Point(0, 83);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(204, 1);
            this.panel22.TabIndex = 10;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel19.Controls.Add(this.textBox12);
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Location = new System.Drawing.Point(158, 92);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(139, 1);
            this.panel19.TabIndex = 33;
            // 
            // textBox12
            // 
            this.textBox12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox12.BackColor = System.Drawing.SystemColors.Control;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox12.Location = new System.Drawing.Point(0, 62);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(203, 20);
            this.textBox12.TabIndex = 11;
            this.textBox12.Text = "Entrer le login";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel20.Location = new System.Drawing.Point(0, 83);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(204, 1);
            this.panel20.TabIndex = 10;
            // 
            // txtPrenomRech
            // 
            this.txtPrenomRech.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtPrenomRech.BackColor = System.Drawing.SystemColors.Control;
            this.txtPrenomRech.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPrenomRech.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtPrenomRech.Location = new System.Drawing.Point(211, 69);
            this.txtPrenomRech.Multiline = true;
            this.txtPrenomRech.Name = "txtPrenomRech";
            this.txtPrenomRech.ReadOnly = true;
            this.txtPrenomRech.Size = new System.Drawing.Size(118, 21);
            this.txtPrenomRech.TabIndex = 26;
            // 
            // btnRecherche
            // 
            this.btnRecherche.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.btnRecherche.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRecherche.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.btnRecherche.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnRecherche.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRecherche.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecherche.ForeColor = System.Drawing.SystemColors.GrayText;
            this.btnRecherche.Location = new System.Drawing.Point(236, 14);
            this.btnRecherche.Name = "btnRecherche";
            this.btnRecherche.Size = new System.Drawing.Size(81, 25);
            this.btnRecherche.TabIndex = 32;
            this.btnRecherche.Text = "Search";
            this.btnRecherche.UseVisualStyleBackColor = false;
            this.btnRecherche.Click += new System.EventHandler(this.btnRechercheClient_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(160, 70);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(43, 13);
            this.label9.TabIndex = 28;
            this.label9.Text = "Prenom";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "Telephone";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel11.Controls.Add(this.textBox7);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Location = new System.Drawing.Point(51, 38);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(167, 1);
            this.panel11.TabIndex = 24;
            // 
            // textBox7
            // 
            this.textBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox7.BackColor = System.Drawing.SystemColors.Control;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Location = new System.Drawing.Point(0, 62);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(203, 20);
            this.textBox7.TabIndex = 11;
            this.textBox7.Text = "Entrer le login";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel12.Location = new System.Drawing.Point(0, 83);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(204, 1);
            this.panel12.TabIndex = 10;
            // 
            // txtNomRech
            // 
            this.txtNomRech.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtNomRech.BackColor = System.Drawing.SystemColors.Control;
            this.txtNomRech.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNomRech.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtNomRech.Location = new System.Drawing.Point(53, 70);
            this.txtNomRech.Multiline = true;
            this.txtNomRech.Name = "txtNomRech";
            this.txtNomRech.ReadOnly = true;
            this.txtNomRech.Size = new System.Drawing.Size(118, 21);
            this.txtNomRech.TabIndex = 23;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel10.Controls.Add(this.panel17);
            this.panel10.Controls.Add(this.textBox2);
            this.panel10.Controls.Add(this.panel13);
            this.panel10.Location = new System.Drawing.Point(6, 92);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(139, 1);
            this.panel10.TabIndex = 24;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel17.Controls.Add(this.textBox10);
            this.panel17.Controls.Add(this.panel18);
            this.panel17.Location = new System.Drawing.Point(0, 0);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(139, 1);
            this.panel17.TabIndex = 25;
            // 
            // textBox10
            // 
            this.textBox10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox10.BackColor = System.Drawing.SystemColors.Control;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.Location = new System.Drawing.Point(0, 62);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(203, 20);
            this.textBox10.TabIndex = 11;
            this.textBox10.Text = "Entrer le login";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel18.Location = new System.Drawing.Point(0, 83);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(204, 1);
            this.panel18.TabIndex = 10;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox2.BackColor = System.Drawing.SystemColors.Control;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(0, 62);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(203, 20);
            this.textBox2.TabIndex = 11;
            this.textBox2.Text = "Entrer le login";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel13.Location = new System.Drawing.Point(0, 83);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(204, 1);
            this.panel13.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 74);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 13);
            this.label5.TabIndex = 25;
            this.label5.Text = "Nom";
            // 
            // txtTelephoneRech
            // 
            this.txtTelephoneRech.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtTelephoneRech.BackColor = System.Drawing.SystemColors.Control;
            this.txtTelephoneRech.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTelephoneRech.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtTelephoneRech.Location = new System.Drawing.Point(73, 19);
            this.txtTelephoneRech.Multiline = true;
            this.txtTelephoneRech.Name = "txtTelephoneRech";
            this.txtTelephoneRech.Size = new System.Drawing.Size(157, 19);
            this.txtTelephoneRech.TabIndex = 23;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(150)))), ((int)(((byte)(243)))));
            this.btnAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnAdd.FlatAppearance.BorderColor = System.Drawing.SystemColors.Highlight;
            this.btnAdd.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.SystemColors.GrayText;
            this.btnAdd.Location = new System.Drawing.Point(343, 31);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(58, 25);
            this.btnAdd.TabIndex = 30;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Date";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel14.Controls.Add(this.textBox9);
            this.panel14.Controls.Add(this.panel15);
            this.panel14.Location = new System.Drawing.Point(49, 68);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(167, 1);
            this.panel14.TabIndex = 18;
            // 
            // textBox9
            // 
            this.textBox9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox9.BackColor = System.Drawing.SystemColors.Control;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Location = new System.Drawing.Point(0, 62);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(203, 20);
            this.textBox9.TabIndex = 11;
            this.textBox9.Text = "Entrer le login";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel15.Location = new System.Drawing.Point(0, 83);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(204, 1);
            this.panel15.TabIndex = 10;
            // 
            // txtDate
            // 
            this.txtDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtDate.BackColor = System.Drawing.SystemColors.Control;
            this.txtDate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDate.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtDate.Location = new System.Drawing.Point(39, 262);
            this.txtDate.Multiline = true;
            this.txtDate.Name = "txtDate";
            this.txtDate.Size = new System.Drawing.Size(189, 19);
            this.txtDate.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Numero";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel16.Controls.Add(this.textBox11);
            this.panel16.Controls.Add(this.panel33);
            this.panel16.Location = new System.Drawing.Point(50, 39);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(167, 1);
            this.panel16.TabIndex = 15;
            // 
            // textBox11
            // 
            this.textBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox11.BackColor = System.Drawing.SystemColors.Control;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Location = new System.Drawing.Point(0, 62);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(203, 20);
            this.textBox11.TabIndex = 11;
            this.textBox11.Text = "Entrer le login";
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.SystemColors.GrayText;
            this.panel33.Location = new System.Drawing.Point(0, 83);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(204, 1);
            this.panel33.TabIndex = 10;
            // 
            // txtNumero
            // 
            this.txtNumero.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtNumero.BackColor = System.Drawing.SystemColors.Control;
            this.txtNumero.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNumero.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtNumero.Location = new System.Drawing.Point(39, 231);
            this.txtNumero.Multiline = true;
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(205, 19);
            this.txtNumero.TabIndex = 14;
            // 
            // Id
            // 
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            // 
            // Libelle
            // 
            this.Libelle.HeaderText = "Libelle";
            this.Libelle.Name = "Libelle";
            // 
            // Prix
            // 
            this.Prix.HeaderText = "Prix";
            this.Prix.Name = "Prix";
            // 
            // Quantite
            // 
            this.Quantite.HeaderText = "Quantite";
            this.Quantite.Name = "Quantite";
            // 
            // Montant
            // 
            this.Montant.HeaderText = "Montant";
            this.Montant.Name = "Montant";
            // 
            // textBox4
            // 
            this.textBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textBox4.BackColor = System.Drawing.SystemColors.Control;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.ForeColor = System.Drawing.SystemColors.GrayText;
            this.textBox4.Location = new System.Drawing.Point(207, 105);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(42, 19);
            this.textBox4.TabIndex = 43;
            this.textBox4.Visible = false;
            // 
            // txtRechPrix
            // 
            this.txtRechPrix.AutoSize = true;
            this.txtRechPrix.Location = new System.Drawing.Point(159, 108);
            this.txtRechPrix.Name = "txtRechPrix";
            this.txtRechPrix.Size = new System.Drawing.Size(24, 13);
            this.txtRechPrix.TabIndex = 41;
            this.txtRechPrix.Text = "Prix";
            this.txtRechPrix.Visible = false;
            // 
            // txtIdRech
            // 
            this.txtIdRech.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.txtIdRech.BackColor = System.Drawing.SystemColors.Control;
            this.txtIdRech.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtIdRech.ForeColor = System.Drawing.SystemColors.GrayText;
            this.txtIdRech.Location = new System.Drawing.Point(70, 106);
            this.txtIdRech.Multiline = true;
            this.txtIdRech.Name = "txtIdRech";
            this.txtIdRech.ReadOnly = true;
            this.txtIdRech.Size = new System.Drawing.Size(42, 19);
            this.txtIdRech.TabIndex = 45;
            this.txtIdRech.Visible = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(22, 109);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(16, 13);
            this.label16.TabIndex = 44;
            this.label16.Text = "Id";
            this.label16.Visible = false;
            // 
            // FrmCommande
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 588);
            this.ControlBox = false;
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dataGridViewAr);
            this.Name = "FrmCommande";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmCommande";
            this.Load += new System.EventHandler(this.FrmCommande_Load);
            ((System.ComponentModel.ISupportInitialize)(this.commandeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gesCom1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gesCom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.articleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientBindingSource1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCommande)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Entity.GesCom gesCom;
        private System.Windows.Forms.BindingSource clientBindingSource;
        private Entity.GesComTableAdapters.ClientTableAdapter clientTableAdapter;
        private System.Windows.Forms.DataGridView dataGridViewAr;
        private Entity.GesCom gesCom1;
        private System.Windows.Forms.BindingSource articleBindingSource;
        private Entity.GesComTableAdapters.ArticleTableAdapter articleTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idArticleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn referenceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn libelleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prixDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categorieDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource commandeBindingSource;
        private Entity.GesComTableAdapters.CommandeTableAdapter commandeTableAdapter;
        private System.Windows.Forms.BindingSource clientBindingSource1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idClientDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prenomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adresseDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn telephoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox txtNom;
        private System.Windows.Forms.TextBox txtPrenom;
        private System.Windows.Forms.TextBox txtTel;
        private System.Windows.Forms.TextBox txtAdresse;
        private System.Windows.Forms.Button btnSaveClient;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label Nom;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNumCom;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker txtDateCom;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridView dgvCommande;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtRefRech;
        private System.Windows.Forms.TextBox txtQuantCom;
        private System.Windows.Forms.TextBox txtQuantRech;
        private System.Windows.Forms.Button btnAddCommande;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Button btnRechArticle;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtLibRech;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtAdresseRech;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TextBox txtPrenomRech;
        private System.Windows.Forms.Button btnRecherche;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txtNomRech;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTelephoneRech;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.TextBox txtDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn Libelle;
        private System.Windows.Forms.DataGridViewTextBoxColumn Prix;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantite;
        private System.Windows.Forms.DataGridViewTextBoxColumn Montant;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label txtRechPrix;
        private System.Windows.Forms.TextBox txtIdRech;
        private System.Windows.Forms.Label label16;
    }
}